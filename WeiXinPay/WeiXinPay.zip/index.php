<!DOCTYPE HTML>
<html>
<head>
	<meta charset="UTF-8">
	<title>微信安全支付</title>
</head>
<body>
	</br></br>
	<div >
		<ul>
			<h1><a href="./demo/js_api_call.php" >1.JSapi支付demo(在微信客户端中点击)</a></h1>
			<h1><a href="./demo/native_call_qrcode.php" >2.native支付模式一demo(用微信扫的静态链接二维码)</a></h1>
			<h1><a href="./demo/native_dynamic_qrcode.php" >3.native支付模式二demo(用微信扫的动态链接二维码)</a></h1>
			<h1><a href="./demo/order_query.php" >4.支付查询接口demo</a></h1>
			<h1><a href="./demo/download_bill.php" >5.对账单接口demo</a></h1>
			<h1><a href="./demo/refund.php" >6.退款接口demo</a></h1>
			<h1><a href="./demo/refund_query.php" >7.退款查询接口demo</a></h1>
		</ul>
	</div>
</body>
</html>