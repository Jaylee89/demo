@ author by sunshine
=========================

(1)微信支付php版jsAPI，公共类155,821行CURLOP_TIMEOUT-> CURLOPT_TIMEOUT;
(2)公共类里171,175行代码重复;
(3) js_api_call.php里面的第91行js有错: if (typeof WeixinJSBridge == "undefined")  ->  if (typeof('WeixinJSBridge') == "undefined")

更多资源请到 https://github.com/chenyangguang查找

